//Header Multiplexor
#ifndef __MTPLX_H
#define __MTPLX_H
//Libreria
#include <xc.h>
#include <stdint.h>

//Funcion (Nombre)
void Timer0 (void);

#endif 