
//Header Interrupciones ADC
#ifndef __ADC_H
#define __ADC_H
//Libreria
#include <xc.h>
#include <stdint.h>

//Funcion (Nombre)
void config_ADC (uint8_t f);

#endif 