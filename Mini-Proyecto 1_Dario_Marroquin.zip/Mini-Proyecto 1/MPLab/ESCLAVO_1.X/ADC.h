#ifndef __ADC_h_
#define __ADC_h_

#include <xc.h>
#include <stdint.h>

void config_ADC();
uint8_t ValorADC(uint8_t x);
#endif
