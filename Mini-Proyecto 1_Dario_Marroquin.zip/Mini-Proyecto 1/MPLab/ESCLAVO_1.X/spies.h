


#ifndef SPI_H
#define	SPI_H

#include <xc.h>
void SPI_ES(void);

#endif	/* SPI_H */

