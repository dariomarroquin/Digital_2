//Header Interrupciones B
#ifndef int_b_H
#define int_b_H

//Libreria
#include <xc.h>

//Funcion (Nombre)
void config_INTB (void);
#endif 