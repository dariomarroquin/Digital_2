//---------------------------------------------
// Dario Marroquin
// SPI
//------------------------------------------------

#ifndef SPI_H
#define SPI_H

#include <xc.h>
void SPIMas(void); 
#endif
